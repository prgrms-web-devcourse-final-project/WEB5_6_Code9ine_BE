package com.grepp.spring.app.model.auth.code;

public enum AuthToken {
    ACCESS_TOKEN, REFRESH_TOKEN, AUTH_SERVER_SESSION_ID
}
