package com.grepp.spring.app.model.auth.code;

public enum Role {
    ROLE_USER,
    ROLE_ADMIN
}
