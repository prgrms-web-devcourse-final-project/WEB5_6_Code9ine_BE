package com.grepp.spring.app.controller.api;

import static org.junit.jupiter.api.Assertions.*;

class MemberResourceTest {

}